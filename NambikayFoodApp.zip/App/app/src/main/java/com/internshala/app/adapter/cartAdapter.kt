package com.internshala.app.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.internshala.app.Model.ItemList
import com.internshala.app.R
import com.internshala.app.database.ItemEntity

class cartAdapter(val context: Context,val itemList: List<ItemEntity>):RecyclerView.Adapter<cartAdapter.cartViewHolder>() {

    class cartViewHolder(view:View) : RecyclerView.ViewHolder(view){
        val cartName : TextView = view.findViewById(R.id.CartFoodItem)
        val cartCost : TextView = view.findViewById(R.id.CartCost)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): cartViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.cart_single_row,parent,false)
        return cartViewHolder(view)
    }

    override fun getItemCount(): Int {
        return itemList.size
    }


    override fun onBindViewHolder(holder: cartViewHolder, position: Int) {
        val item = itemList[position]

        holder.cartName.text = item.name
        holder.cartCost.text = item.cost


    }
}