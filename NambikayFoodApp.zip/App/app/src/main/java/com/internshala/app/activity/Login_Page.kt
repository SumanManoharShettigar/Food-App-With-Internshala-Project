package com.internshala.app.activity

import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.ConnectivityManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.text.method.PasswordTransformationMethod
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.core.app.ActivityCompat
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.internshala.app.NoInternet
import com.internshala.app.R
import com.internshala.app.util.ConnectionManager
import org.json.JSONException
import org.json.JSONObject

class Login_Page : AppCompatActivity() {

    lateinit var txtLogInPh : EditText
    lateinit var txtLogInPwd : EditText
    lateinit var btnLogIn : Button
    lateinit var btnFrgtPwd : Button
    lateinit var btnRegister : Button


    lateinit var sharedPreferences: SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login_page)
        sharedPreferences =
            getSharedPreferences(getString(R.string.preference_file_name), Context.MODE_PRIVATE)
        val isLoggedIn = sharedPreferences.getBoolean("isLoggedIn", false)
        setContentView(R.layout.login_page)
        if (isLoggedIn) {
            val intent = Intent(this@Login_Page, HomePage::class.java)
            startActivity(intent)
            finish()
        }


        txtLogInPh = findViewById(R.id.txtLogInPh)
        txtLogInPwd = findViewById(R.id.txtLogInPwd)
        btnLogIn = findViewById(R.id.btnLogIn)
        btnFrgtPwd = findViewById(R.id.btnFrgtPwd)
        btnRegister = findViewById(R.id.btnRegister)





        btnLogIn.setOnClickListener {
            //Check Connectivity First

            val mobileNumber = txtLogInPh.text.toString()
            val password = txtLogInPwd.text.toString()

            val queue = Volley.newRequestQueue(this@Login_Page)

            val url = "http://13.235.250.119/v2/login/fetch_result"

            val params = JSONObject()
            params.put("mobile_number", mobileNumber)
            params.put("password", password)

            if (ConnectionManager().checkConnectivity(this@Login_Page)) {

                val mobileNumber = txtLogInPh.text.toString()
                val password = txtLogInPwd.text.toString()
                val intent = Intent(this@Login_Page, HomePage::class.java)

                val queue = Volley.newRequestQueue(this@Login_Page)

                val url = "http://13.235.250.119/v2/login/fetch_result"

                val params = JSONObject()
                params.put("mobile_number", mobileNumber)
                params.put("password", password)

                val request =object:
                    JsonObjectRequest(Request.Method.POST, url, params, Response.Listener {
                        try{

                        val data1 = it.getJSONObject("data")

                        val success = data1.getBoolean("success")

                        if(success){

                            val data = data1.getJSONObject("data")

                            val userId1 = data.getString("user_id").toString()
                            val name1 = data.getString("name").toString()
                            val email1 = data.getString("email").toString()
                            val mobileNumber1 = data.getString("mobile_number").toString()
                            val address1 = data.getString("address").toString()

                            savePreference(userId1,name1,email1,mobileNumber1,password,address1)


                            val intent = Intent(this@Login_Page, HomePage::class.java)
                            startActivity(intent)
                            finish()






                        }

                        else{

                            Toast.makeText(this@Login_Page,data1.getString("errorMessage"),Toast.LENGTH_SHORT).show()

                        }

                    }
                        catch (e:JSONException){
                            Toast.makeText(this@Login_Page,"Exception Error",Toast.LENGTH_SHORT).show()
                        }
                    }
                        ,

                        Response.ErrorListener {
                            Toast.makeText(this@Login_Page,"Volley Error",Toast.LENGTH_SHORT).show()


                        })
                    {
                        override fun getHeaders(): MutableMap<String, String> {
                            val headers = HashMap<String,String>()
                            headers["Content-type"]="application/json"
                            headers["token"]="a64e7228772c2c"
                            return headers
                        }
                    }

                queue.add(request)





            } else {

                NoInternet(this@Login_Page)
            }
        }


            btnRegister.setOnClickListener {
                val intent = Intent(this@Login_Page, Register::class.java)
                startActivity(intent)

            }

            btnFrgtPwd.setOnClickListener {
                val intent = Intent(this@Login_Page, ForgotPassword::class.java)
                startActivity(intent)

            }

        }

    fun savePreference(userId:String,name : String,email : String,phone : String,password : String,address : String){
        sharedPreferences.edit().putString("Name",name).apply()
        sharedPreferences.edit().putString("Email",email).apply()
        sharedPreferences.edit().putString("MobileNumber",phone).apply()
        sharedPreferences.edit().putString("Password",password).apply()
        sharedPreferences.edit().putBoolean("isLoggedIn",true).apply()
        sharedPreferences.edit().putString("user_id",userId).apply()
        sharedPreferences.edit().putString("address",address).apply()


    }


    override fun onBackPressed() {
        finish()
    }
}