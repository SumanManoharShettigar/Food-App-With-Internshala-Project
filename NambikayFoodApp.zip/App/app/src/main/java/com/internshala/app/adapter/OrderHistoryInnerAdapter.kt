package com.internshala.app.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.internshala.app.Model.ItemList
import com.internshala.app.R

class OrderHistoryInnerAdapter(val context: Context, val itemList: List<ItemList>):RecyclerView.Adapter<OrderHistoryInnerAdapter.orderHistoryInnerViewHolder>() {

    class orderHistoryInnerViewHolder(view:View) : RecyclerView.ViewHolder(view){
        val cartName : TextView = view.findViewById(R.id.CartFoodItem)
        val cartCost : TextView = view.findViewById(R.id.CartCost)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): orderHistoryInnerViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.cart_single_row,parent,false)
        return orderHistoryInnerViewHolder(view)
    }

    override fun getItemCount(): Int {
        return itemList.size
    }


    override fun onBindViewHolder(holder: orderHistoryInnerViewHolder, position: Int) {
        val item = itemList[position]

        holder.cartName.text = item.item_name
        holder.cartCost.text = item.item_cost


    }
}