package com.internshala.app.database

import androidx.room.Database
import androidx.room.RoomDatabase

//In @Database we have to mention the table which the database will have with the name of the Class.

//version is used because when an app is updated the the updated database will have number greater than previous database version.

@Database(entities = [RestaurantEntity::class],version = 1)
abstract class RestaurantDataBase : RoomDatabase() {

    //We need to tell that all functions performed here will be by thr DAO Interface

    abstract fun restaurantDao() : RestaurantDao
}