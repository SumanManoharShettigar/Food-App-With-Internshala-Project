package com.internshala.app.activity

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.method.PasswordTransformationMethod
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.internshala.app.NoInternet
import com.internshala.app.R
import com.internshala.app.util.ConnectionManager
import kotlinx.android.synthetic.main.forgot_password.*
import org.json.JSONException
import org.json.JSONObject

class ForgotPassword : AppCompatActivity() {
    lateinit var txtfrgtpwdMobileNumber : EditText
    lateinit var txtfrgtpwdEmail : EditText
    lateinit var sharedPreferences: SharedPreferences
    lateinit var progressBar : ProgressBar
    lateinit var progressBarLayout : RelativeLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.forgot_password)
        sharedPreferences = getSharedPreferences(getString(R.string.preference_file_name), Context.MODE_PRIVATE)
        txtfrgtpwdMobileNumber = findViewById(R.id.txtfrgtpwdMobileNumber)
        txtfrgtpwdEmail = findViewById(R.id.txtfrgtpwdEmail)

        progressBar = findViewById(R.id.progressBar)
        progressBarLayout = findViewById(R.id.progressBarLayout)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setHomeButtonEnabled(true)

       removeProgressBar()





        btnRetrieve.setOnClickListener{
            val mobileNumber = txtfrgtpwdMobileNumber.text.toString()
            val email = txtfrgtpwdEmail.text.toString()


            if(mobileNumber == "" || email == "")
            {
                Toast.makeText(this@ForgotPassword,"Missing/Wrong Credentials",Toast.LENGTH_LONG).show()

            }
            else {
                btnRetrieve.visibility = View.GONE
                progressBar.visibility = View.VISIBLE
                progressBarLayout.visibility = View.VISIBLE


                val queue = Volley.newRequestQueue(this@ForgotPassword)
                val url = "http://13.235.250.119/v2/forgot_password/fetch_result"
                val param = JSONObject()
                param.put("mobile_number", mobileNumber)
                param.put("email", email)

                if (ConnectionManager().checkConnectivity(this@ForgotPassword) == true) {

                    val request = object: JsonObjectRequest(Request.Method.POST,url,param,Response.Listener {

                        try{
                            val data = it.getJSONObject("data")

                            val success = data.getBoolean("success")


                            if(success){
                                val firstTry = data.getBoolean("first_try")

                                val successDialog = AlertDialog.Builder(this@ForgotPassword,R.style.CustomDialogTheme)
                                successDialog.setMessage("The OTP Code has been sent to your Email.")
                                successDialog.setPositiveButton("Ok"){
                                    text,listener ->

                                    progressBar.visibility = View.GONE

                                    val intent = Intent(this@ForgotPassword,ResetPassword::class.java)
                                    startActivity(intent)
                                    savePreferences(mobileNumber,email)
                                    progressBarLayout.visibility = View.GONE
                                    btnRetrieve.visibility= View.VISIBLE


                                }
                                successDialog.create()
                                successDialog.show()

                            }
                            else{
                                Toast.makeText(this@ForgotPassword,data.getString("errorMessage"),Toast.LENGTH_SHORT).show()
                                removeProgressBar()
                            }
                        }
                        catch (e: JSONException){
                            Toast.makeText(this@ForgotPassword,"Exception Error Occurred",Toast.LENGTH_SHORT).show()
                            removeProgressBar()
                        }

                    },
                    Response.ErrorListener {
                        Toast.makeText(this@ForgotPassword,"Volley Error Occurred",Toast.LENGTH_SHORT).show()
                        removeProgressBar()

                    })
                    {
                        override fun getHeaders(): MutableMap<String, String> {
                            val headers = HashMap<String,String>()
                            headers["Content-type"]="application/json"
                            headers["token"] = "a64e7228772c2c"
                            return headers
                        }
                    }

                    queue.add(request)
                }

                else{
                    NoInternet(this@ForgotPassword)

                }

            }
        }
    }
    fun savePreferences(mobileNumber : String,email : String){
        sharedPreferences.edit().putString("MobileNumber",mobileNumber).apply()
        sharedPreferences.edit().putString("Email",email).apply()
    }
    fun removeProgressBar(){
        progressBarLayout.visibility = View.GONE
        progressBar.visibility = View.GONE
        btnRetrieve.visibility= View.VISIBLE
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        if(id == android.R.id.home){
            onBackPressed()

            return true
        }
        return false
    }

    override fun onBackPressed() {
        finish()
        super.onBackPressed()

    }
}