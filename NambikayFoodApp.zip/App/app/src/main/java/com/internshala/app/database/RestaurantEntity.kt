package com.internshala.app.database

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

//Entity is the other term for table
@Entity(tableName = "restaurants")
data class RestaurantEntity (
    //Primar Key is to identify the required value among similar strings
    @PrimaryKey val res_id : Int,
    //ColumInfo puts the val variable values under the name mentioned inside @ColumInfo in the Table restaurants
    @ColumnInfo(name = "restaurant_name") val res_Name : String,
    @ColumnInfo(name = "restaurant_rating") val res_Rating : String,
    @ColumnInfo(name = "restaurant_cost") val res_Cost : String,
    @ColumnInfo(name = "restaurant_image") val res_Image : String
)

