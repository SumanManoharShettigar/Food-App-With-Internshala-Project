package com.internshala.app.activity

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.AsyncTask
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.print.PrintAttributes
import android.view.*
import android.widget.Button
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.Toolbar
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.view.marginBottom
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.internshala.app.Model.ItemList
import com.internshala.app.R
import com.internshala.app.adapter.RestaurantMenuAdapter
import com.internshala.app.database.ItemDatabase
import com.internshala.app.database.ItemEntity
import org.json.JSONException
import org.json.JSONObject
import java.util.*
import kotlin.collections.ArrayList
import kotlin.collections.HashMap

class RestaurantItemList : AppCompatActivity(), RestaurantMenuAdapter.onClickListener {

    lateinit var itemCoordinator: CoordinatorLayout
    lateinit var itemToolbar: Toolbar
    lateinit var itemRecyclerView: RecyclerView
    lateinit var itemAdapter: RestaurantMenuAdapter
    lateinit var itemLayout: RecyclerView.LayoutManager
    lateinit var proceedButton: Button


    lateinit var itemProgressBarLayout: RelativeLayout
    lateinit var itemProgressBar: ProgressBar
    lateinit var sharedPreferences: SharedPreferences

    lateinit var RecyclerViewLayout: RelativeLayout
    val itemList = ArrayList<ItemList>()

    var selectedItem = -1

    //Sort
    val nameComparator = Comparator<ItemList> { item1, item2 ->

        if(item1.item_name.compareTo(item2.item_name,true) == 0){
            item1.item_cost.compareTo(item2.item_cost,true)

    }
    else{
            item1.item_name.compareTo(item2.item_name,true)
        }}

    val costComparator = Comparator<ItemList> { item1, item2 ->


        if(item1.item_cost.toInt().compareTo(item2.item_cost.toInt()) == 0){
            item1.item_name.compareTo(item2.item_name,true)


        }
        else{

            item1.item_cost.toInt().compareTo(item2.item_cost.toInt())
        }}



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_restaurant_item_list)
        proceedButton = findViewById(R.id.proceedButton)
        proceedButton.visibility = View.GONE

        sharedPreferences = getSharedPreferences("Restaurant Details", Context.MODE_PRIVATE)

        RecyclerViewLayout = findViewById(R.id.RecyclerViewLayout)

        itemCoordinator = findViewById(R.id.itemCoordinator)
        itemToolbar = findViewById(R.id.itemToolbar)
        itemRecyclerView = findViewById(R.id.itemRecyclerView)
        itemLayout = LinearLayoutManager(this@RestaurantItemList)
        itemProgressBar = findViewById(R.id.itemProgressBar)
        itemProgressBarLayout = findViewById(R.id.itemProgressBarLayout)



        itemProgressBar.visibility = View.VISIBLE
        itemProgressBarLayout.visibility = View.VISIBLE

        setToolBar()
        itemDatabase1(this@RestaurantItemList, 2).execute()


        val id = sharedPreferences.getString("id", null)
        val queue = Volley.newRequestQueue(this@RestaurantItemList)
        val url = "http://13.235.250.119/v2/restaurants/fetch_result/$id"

        val request = object : JsonObjectRequest(Request.Method.GET, url, null, Response.Listener {

            try {
                itemProgressBarLayout.visibility = View.GONE
                itemProgressBar.visibility = View.GONE

                val data1 = it.getJSONObject("data")

                val success = data1.getBoolean("success")

                if (success) {
                    val data = data1.getJSONArray("data")


                    for (i in 0 until data.length()) {
                        val itemListJSONObject = data.getJSONObject(i)


                        val itemListObject = ItemList(
                            itemListJSONObject.getString("id"),
                            itemListJSONObject.getString("name"),
                            itemListJSONObject.getString("cost_for_one")
                        )

                        itemList.add(itemListObject)

                        itemAdapter = RestaurantMenuAdapter(this@RestaurantItemList, this, itemList)

                        itemRecyclerView.adapter = itemAdapter
                        itemRecyclerView.layoutManager = itemLayout


                    }

                }
            } catch (e: JSONException) {
                Toast.makeText(
                    this@RestaurantItemList,
                    "Exception Error Occurred",
                    Toast.LENGTH_SHORT
                ).show()
            }

        },
            Response.ErrorListener {
                Toast.makeText(this@RestaurantItemList, "Volley Error Occurred", Toast.LENGTH_SHORT)
                    .show()

            }) {
            override fun getHeaders(): MutableMap<String, String> {
                val headers = HashMap<String, String>()
                headers["Content-type"] = "application/json"
                headers["token"] = "a64e7228772c2c"
                return headers
            }

        }
        queue.add(request)

        proceedButton.setOnClickListener {
            val intent = Intent(this@RestaurantItemList, Cart::class.java)
            startActivity(intent)
        }


    }


    fun setToolBar() {
        setSupportActionBar(itemToolbar)
        supportActionBar?.title = "Restaurant Item"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setHomeButtonEnabled(true)

    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        if (id == android.R.id.home) {
            if (itemDatabase1(this@RestaurantItemList, 1).execute().get() == false) {
                val dialog = AlertDialog.Builder(this@RestaurantItemList,R.style.CustomDialogTheme)
                dialog.setTitle("Confirmation")
                dialog.setMessage("Going back will reset cart items. Do you wish to proceed?")
                dialog.setPositiveButton("Ok") { text, listener ->
                    itemDatabase1(this@RestaurantItemList, 2).execute()
                    onBackPressed()
                }

                dialog.setNegativeButton("Cancel") { text, listener ->
                }
                dialog.create()
                dialog.show()
                return true
            } else {
                onBackPressed()
                return true

            }

        }


        else if (id == R.id.sort) {

            var sortOption = arrayOf("Name","Cost(Low to High)","Cost(High to Low)")


            val dialog = AlertDialog.Builder(this@RestaurantItemList)
            dialog.setTitle("Sort by")

            dialog.setSingleChoiceItems(sortOption, selectedItem) { text, i ->
                selectedItem = i


            }



            dialog.setPositiveButton("Close"){
                    text, listener ->
                when(selectedItem){

                    0 -> {
                        Collections.sort(itemList,nameComparator)
                        //DO TELL THE ADAPTER ABOUT THE CHANGES
                        itemAdapter.notifyDataSetChanged()



                    }

                    1 -> {
                        
                        Collections.sort(itemList,costComparator)
                        //DO TELL THE ADAPTER ABOUT THE CHANGES
                        itemAdapter.notifyDataSetChanged()
                    }

                    2 ->{
                        Collections.sort(itemList,costComparator)
                        itemList.reverse()
                        //DO TELL THE ADAPTER ABOUT THE CHANGES
                        itemAdapter.notifyDataSetChanged()
                    }


                }
            }


            dialog.create()
            dialog.show()








        }



        else {
            return super.onOptionsItemSelected(item)
        }

        return false
    }

    override fun onBackPressed() {
        if (itemDatabase1(this@RestaurantItemList, 1).execute().get() == false) {
            val dialog = AlertDialog.Builder(this@RestaurantItemList)
            dialog.setTitle("Confirmation")
            dialog.setMessage("Going back will reset cart items. Do you wish to proceed?")
            dialog.setPositiveButton("Ok") { text, listener ->
                itemDatabase1(this@RestaurantItemList, 2).execute()
                super.onBackPressed()
            }

            dialog.setNegativeButton("Cancel") { text, listener ->
            }
            dialog.create()
            dialog.show()

        }
        else{
            super.onBackPressed()
        }

    }


    class itemDatabase1(val context: Context, val mode: Int) :
        AsyncTask<Void, Void, Boolean>() {

        val db = Room.databaseBuilder(context, ItemDatabase::class.java, "item-db").build()
        override fun doInBackground(vararg p0: Void?): Boolean {
            //mode 1 for checking item count in database
            //mode 2 for deleting all item in database
            when (mode) {

                1 -> {
                    if ((db.itemDao().getCount()) > 0) {
                        db.close()
                        return false
                    } else {
                        db.close()
                        return true
                    }
                }

                2 -> {
                    db.itemDao().deleteAll()
                    db.close()
                    return true
                }
            }
            db.close()
            return true

        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        //For Sort Symbol

        var inflater = menuInflater
        inflater?.inflate(R.menu.menu_home,menu
        )
        return true
    }





    override fun onButtonClick(button: Button, position: Int) {

        if (itemDatabase1(this@RestaurantItemList, 1).execute().get() == false) {
            proceedButton.visibility = View.VISIBLE
            val param = RecyclerViewLayout.layoutParams as ViewGroup.MarginLayoutParams
            param.bottomMargin = 300
            RecyclerViewLayout.layoutParams = param

        } else {
            proceedButton.visibility = View.GONE
            val param = RecyclerViewLayout.layoutParams as ViewGroup.MarginLayoutParams
            param.bottomMargin = 0
            RecyclerViewLayout.layoutParams = param

        }
    }
}

private fun Int.compareTo(toInt: Int): Int {


        return this.compareTo(toInt)

}
