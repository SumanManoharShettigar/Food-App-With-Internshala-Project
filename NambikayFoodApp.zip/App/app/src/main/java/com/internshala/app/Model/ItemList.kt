package com.internshala.app.Model
 data class  ItemList (
    val item_id : String,
    val item_name : String,
    val item_cost : String
)
