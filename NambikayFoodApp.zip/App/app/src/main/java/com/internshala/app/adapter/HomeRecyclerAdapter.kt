package com.internshala.app.adapter

import android.app.PendingIntent.getActivity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.AsyncTask
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.core.graphics.drawable.toDrawable
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.internshala.app.Model.Restaurant
import com.internshala.app.NoInternet
import com.internshala.app.R
import com.internshala.app.activity.RestaurantItemList
import com.internshala.app.database.RestaurantDataBase
import com.internshala.app.database.RestaurantEntity
import com.internshala.app.fragment.HomeFragment
import com.internshala.app.util.ConnectionManager
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.recycler_home_single_row.view.*
import java.util.zip.Inflater

class HomeRecyclerAdapter(val context: Context,val restaurantList : ArrayList<Restaurant>)
    : RecyclerView.Adapter<HomeRecyclerAdapter.homeViewHolder>() {
    val sharedPreferences = context.getSharedPreferences("Restaurant Details",Context.MODE_PRIVATE)



    class homeViewHolder(
        view: View
    ) : RecyclerView.ViewHolder(view) {

        //Initialise the view of single recycler row

        val homeRecyclerImg: ImageView = view.findViewById(R.id.homeRecyclerImg)
        val homeRecyclerName: TextView = view.findViewById(R.id.homeRecyclerName)
        val homeRecyclerCost: TextView = view.findViewById(R.id.homeRecyclerCost)
        val homeRecyclerFavourite: ImageView = view.findViewById(R.id.homeRecyclerFavourite)
        val homeRecyclerRating: TextView = view.findViewById(R.id.homeRecyclerRating)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): homeViewHolder {

        //Creates the first views in the recycler view . Inflate the recycler_home_single_row

        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.recycler_home_single_row, parent, false)
        return homeViewHolder(view)
    }

    override fun getItemCount(): Int {
        return restaurantList.size

    }

    override fun onBindViewHolder(holder: homeViewHolder, position: Int) {
        //Initialising Views of "recycler_home_single_row" with the values in ArrayList



        val restaurant = restaurantList[position]

        holder.homeRecyclerName.text = restaurant.res_Name
        holder.homeRecyclerCost.text = restaurant.res_Cost
        holder.homeRecyclerRating.text = restaurant.res_Rating


        //Picasso used to load from val restaurant = restaurantList[position]
        Picasso.get().load(restaurant.res_Image).error(R.drawable.defaultdine)
            .into(holder.homeRecyclerImg)


        val restaurantEntity = RestaurantEntity(
            restaurant.res_id.toInt(),
            restaurant.res_Name,
            restaurant.res_Rating,
            restaurant.res_Cost,
            restaurant.res_Image
        )


        //Check the favorite DB for current Restaurant


        val checkfav = DBAsyncTask(
            context,
            restaurantEntity,
            1
        ).execute()
        //Above Code is an Object

        //check the Boolean response for the above object
        val isFav = checkfav.get()

        if(isFav){
            holder.homeRecyclerFavourite.setImageResource(R.drawable.checked_fav)
        }
        else
        {
            holder.homeRecyclerFavourite.setImageResource(R.drawable.uncheck_fav)
        }


        //Making Like Button Function

        holder.homeRecyclerFavourite.setOnClickListener {


            if (!DBAsyncTask(context, restaurantEntity, 1).execute().get())
            //Find Out if the restaurant is not there
            {
                //Add the book
                val async = DBAsyncTask(context,restaurantEntity,2).execute()
                //Above Code is an Object
                val result = async.get()

                if(result){
                    Toast.makeText(context,"Restaurant is added to Favorites",Toast.LENGTH_SHORT).show()
                    holder.homeRecyclerFavourite.setImageResource(R.drawable.checked_fav)
                }
                else{
                    Toast.makeText(context,"Some Error Occurred!!",Toast.LENGTH_SHORT).show()
                }
            }
            else{
                //Delete the restaurant from favourite
                val async = DBAsyncTask(context,restaurantEntity,3).execute()
                //Above Code is an Object
                val result = async.get()

                if(result){
                    Toast.makeText(context,"Restaurant is Removed From Favorites",Toast.LENGTH_SHORT).show()
                    holder.homeRecyclerFavourite.setImageResource(R.drawable.uncheck_fav)
                }
                else{
                    Toast.makeText(context,"Some Error Occurred!",Toast.LENGTH_SHORT).show()
                }
            }
        }

        //On click For Each Restaurant
        holder.itemView.setOnClickListener {

            savedPreference(restaurant.res_id,restaurant.res_Name)

            if(ConnectionManager().checkConnectivity(context)){

                val intent = Intent(context,RestaurantItemList::class.java)
                context.startActivity(intent)


            }

            else{
                NoInternet(context)
            }





        }

    }

    fun savedPreference(id:String,restaurantName:String){
        sharedPreferences.edit().putString("name",restaurantName).apply()
        sharedPreferences.edit().putString("id",id).apply()
    }

    //We want to inherit the AsyncTask but one class is already inherited up top , so we use subclass
    //Context is needed for the App to know which Part made the request
    //Here restaurant will be added to favorite or not and restaurant entity is needed for that
    class DBAsyncTask(
        val context: Context?,
        val restaurantEntity: RestaurantEntity,
        val mode: Int
    ) : AsyncTask<Void, Void, Boolean>() {

        //Initialise the DB Class as AsyncTask needs it
        //"restaurant-db" is the name of DB
        val db =
            context?.let {
                Room.databaseBuilder(it, RestaurantDataBase::class.java, "restaurant-db").build()
            }


        /*
        Mode 1 -> Check DB if the restaurant is added to the Favorite
        Mode 2 -> Add restaurant to Favorite
        Mode 3-> Remove Restaurant from Favorite
         */

        override fun doInBackground(vararg p0: Void?): Boolean {

            when (mode) {

                1 -> {

                    val restaurant: RestaurantEntity? =
                        db?.restaurantDao()?.getRestaurantById(restaurantEntity.res_id.toString())
                    db?.close()
                    return restaurant != null

                }

                2 -> {
                    db?.restaurantDao()?.insertRestaurant(restaurantEntity)
                    db?.close()
                    return true

                }

                3 -> {
                    db?.restaurantDao()?.deleteRestaurant(restaurantEntity)
                    db?.close()
                    return true

                }
            }

            return false
        }
    }
}