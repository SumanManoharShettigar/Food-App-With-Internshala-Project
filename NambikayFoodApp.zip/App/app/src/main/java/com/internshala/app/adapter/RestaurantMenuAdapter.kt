package com.internshala.app.adapter

import android.content.Context
import android.os.AsyncTask
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.internshala.app.Model.ItemList
import com.internshala.app.R
import com.internshala.app.database.ItemDatabase
import com.internshala.app.database.ItemEntity
import kotlinx.android.synthetic.main.single_row_item_list.view.*

//Add clickListener for the Proceed To Cart Button that is going to be used in Activity
class RestaurantMenuAdapter(val context:Context,var clickListener: onClickListener,val itemList:ArrayList<ItemList>) :
    RecyclerView.Adapter<RestaurantMenuAdapter.ItemViewHolder>() {

    class ItemViewHolder(view: View) : RecyclerView.ViewHolder(view){
        val itemId : TextView = view.findViewById(R.id.itemId)
        val itemName : TextView = view.findViewById(R.id.itemName)
        val itemCost : TextView = view.findViewById(R.id.itemCost)
        val cartButton : Button = view.findViewById(R.id.cartButton)

        //Initialising the buttonclick
        fun initialise(action : onClickListener){

                action.onButtonClick(cartButton,adapterPosition)


        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.single_row_item_list,parent,false)
        return ItemViewHolder(view)
    }

    //For Using Proceed to Cart Button in Activity
    interface onClickListener{
        fun onButtonClick(button: Button,position: Int)
    }

    override fun getItemCount(): Int {

        return itemList.size

    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val item = itemList[position]

        holder.itemId.text = (position + 1).toString()
        holder.itemName.text = item.item_name
        holder.itemCost.text = item.item_cost

        val itemEntity = ItemEntity(
            (position+1).toString(),
            item.item_name,
            item.item_cost
        )

        if(itemDatabase(context,itemEntity,1).execute().get()){
            holder.cartButton.text = "Remove from Cart"
            holder.cartButton.setBackgroundResource(R.drawable.removecart)
        }
        else{
            holder.cartButton.text = "Add to Cart"
            holder.cartButton.setBackgroundResource(R.drawable.button)

        }


        holder.cartButton.setOnClickListener() {




            if (!itemDatabase(context, itemEntity, 1).execute().get()) {
                //item not there in cart

                val itemCart = itemDatabase(context, itemEntity, 2).execute()

                val isInCart = itemCart.get()
                if(isInCart){
                    //If item in Cart

                    holder.cartButton.text = "Remove from Cart"
                    holder.cartButton.setBackgroundResource(R.drawable.removecart)
                    //Using listener for Proceed Button
                    holder.initialise(clickListener)

                }
                else{
                    Toast.makeText(context,"Some Error Occurred",Toast.LENGTH_SHORT).show()
                }

            }
            else{
                val itemCart = itemDatabase(context,itemEntity,3).execute()
                val notInCart = itemCart.get()

                if(notInCart){
                    //Not in Cart
                    holder.cartButton.text = "Add to Cart"
                    holder.cartButton.setBackgroundResource(R.drawable.button)
                    //Using listener for Proceed Button
                    holder.initialise(clickListener)
                }
                else{
                    Toast.makeText(context,"Some Error Occurred",Toast.LENGTH_SHORT).show()

                }
            }
        }



    }

    class itemDatabase (val context: Context,val itemEntity: ItemEntity,val mode: Int):AsyncTask<Void,Void,Boolean>(){

        val db = Room.databaseBuilder(context,ItemDatabase::class.java,"item-db").build()
        override fun doInBackground(vararg p0: Void?): Boolean {


            when(mode){
                //Check if item is added to cart
                1->{
                    val item:ItemEntity = db.itemDao().getItemId(itemEntity.id)
                    db.close()
                    return item != null

                }
                //Add To Cart

                2->{
                    db.itemDao().insertItem(itemEntity)
                    db.close()
                    return true

                }
                //Remove From Cart

                3->{
                    db.itemDao().deleteItem(itemEntity)
                    db.close()
                    return true
                }




            }


            return false
        }


    }

}