package com.internshala.app.database

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "item")

data class ItemEntity (
    @PrimaryKey val id : String,
    @ColumnInfo(name = "name")val name : String,
    @ColumnInfo(name ="cost")val cost : String
)