package com.internshala.app.Model

import org.json.JSONArray

data class OrderInfo (
    val orderId : String,
    val restaurantName : String,
    val totalCost : String,
    val orderTime : String,
    val food_items : JSONArray
)