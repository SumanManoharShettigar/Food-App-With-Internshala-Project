package com.internshala.app.adapter

import android.content.Context
import android.content.Intent
import android.os.AsyncTask
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Database
import androidx.room.Room
import com.internshala.app.Model.Restaurant
import com.internshala.app.R
import com.internshala.app.activity.RestaurantItemList
import com.internshala.app.database.RestaurantDataBase
import com.internshala.app.database.RestaurantEntity
import com.squareup.picasso.Picasso
import java.util.zip.Inflater

class FavoriteAdapter(val context: Context,val restaurantlist: List<RestaurantEntity>) : RecyclerView.Adapter<FavoriteAdapter.FavouriteViewHolder>(){
        val sharedPreferences = context.getSharedPreferences("Restaurant Details",Context.MODE_PRIVATE)

    class FavouriteViewHolder(view: View) : RecyclerView.ViewHolder(view){
        val homeRecyclerImg: ImageView = view.findViewById(R.id.homeRecyclerImg)
        val homeRecyclerName: TextView = view.findViewById(R.id.homeRecyclerName)
        val homeRecyclerCost: TextView = view.findViewById(R.id.homeRecyclerCost)
        val homeRecyclerFavourite: ImageView = view.findViewById(R.id.homeRecyclerFavourite)
        val homeRecyclerRating: TextView = view.findViewById(R.id.homeRecyclerRating)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FavouriteViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.recycler_home_single_row,parent,false)
        return FavouriteViewHolder(view)
    }

    override fun getItemCount(): Int {
        return restaurantlist.size
    }

    override fun onBindViewHolder(holder: FavouriteViewHolder, position: Int) {
        val restaurant = restaurantlist[position]

        holder.homeRecyclerName.text = restaurant.res_Name
        holder.homeRecyclerCost.text = restaurant.res_Cost
        holder.homeRecyclerRating.text = restaurant.res_Rating
        Picasso.get().load(restaurant.res_Image).error(R.drawable.defaultdine).into(holder.homeRecyclerImg)
        val checkFav = DBAsyncTask(context,restaurant,1).execute()

        val isFav = checkFav.get()

        if(isFav){

            holder.homeRecyclerFavourite.setImageResource(R.drawable.checked_fav)
        }
        else{

            holder.homeRecyclerFavourite.setImageResource(R.drawable.uncheck_fav)
        }


        //On click For Each Restaurant
        holder.itemView.setOnClickListener {

            savedPreference(restaurant.res_id.toString(),restaurant.res_Name)


            val intent = Intent(context, RestaurantItemList::class.java)
            context.startActivity(intent)





        }


        holder.homeRecyclerFavourite.setOnClickListener {

            if(!DBAsyncTask(context,restaurant,1).execute().get()){

                val async = DBAsyncTask(context,restaurant,2).execute()

                val result = async.get()

                if (result){
                    Toast.makeText(context,"Restaurant is added to Favorites", Toast.LENGTH_SHORT).show()
                    holder.homeRecyclerFavourite.setImageResource(R.drawable.checked_fav)
                }

                else{
                    Toast.makeText(context,"Some Error Occurred", Toast.LENGTH_SHORT).show()


                }

            }
            else{
                val async = DBAsyncTask(context,restaurant,3).execute()

                val result = async.get()

                if (result){
                    Toast.makeText(context,"Restaurant is Removed From Favorites", Toast.LENGTH_SHORT).show()
                    holder.homeRecyclerFavourite.setImageResource(R.drawable.uncheck_fav)
                }

                else{
                    Toast.makeText(context,"Some Error Occurred",Toast.LENGTH_SHORT).show()
                }
            }
        }



    }
    fun savedPreference(id:String,restaurantName:String){
        sharedPreferences.edit().putString("restaurant_id",restaurantName).apply()
        sharedPreferences.edit().putString("id",id).apply()
    }

    class DBAsyncTask(val context: Context,val restaurantEntity: RestaurantEntity,val mode : Int) : AsyncTask<Void,Void,Boolean>(){

        val db = Room.databaseBuilder(context,RestaurantDataBase::class.java,"restaurant-db").build()
        override fun doInBackground(vararg p0: Void?): Boolean {

            when(mode){

                1 -> {
                    val restaurant = db.restaurantDao().getRestaurantById(restaurantEntity.res_id.toString())
                    db.close()
                    return restaurant != null
                }

                2 -> {
                    db.restaurantDao().insertRestaurant(restaurantEntity)
                    db.close()
                    return true
                }

                3 -> {
                    db.restaurantDao().deleteRestaurant(restaurantEntity)
                    db.close()
                    return true
                }
            }
            return false

        }


    }

}