package com.internshala.app.activity

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.AsyncTask
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.widget.Toolbar
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.internshala.app.NoInternet
import com.internshala.app.R
import com.internshala.app.adapter.cartAdapter
import com.internshala.app.database.ItemDatabase
import com.internshala.app.database.ItemEntity
import com.internshala.app.util.ConnectionManager

import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import kotlin.collections.HashMap

class Cart : AppCompatActivity() {
    lateinit var cartRecyclerView: RecyclerView
    lateinit var cartCoordinator: CoordinatorLayout
    lateinit var cartLayout: RecyclerView.LayoutManager
    lateinit var cartAdapter: cartAdapter
    lateinit var orderButton: Button
    lateinit var CartToolbar: Toolbar
    lateinit var sharedPreferencesUser: SharedPreferences
    lateinit var sharedPreferencesRestaurant: SharedPreferences

    var itemList = listOf<ItemEntity>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cart)
        var restaurant: String?

        sharedPreferencesRestaurant =
            getSharedPreferences("Restaurant Details", Context.MODE_PRIVATE)

        sharedPreferencesUser = getSharedPreferences("User Details", Context.MODE_PRIVATE)


        CartToolbar = findViewById(R.id.CartToolbar)

        cartRecyclerView = findViewById(R.id.cartRecyclerView)
        orderButton = findViewById(R.id.ConfirmOrder)
        cartCoordinator = findViewById(R.id.cartCoordinator)

        cartLayout = LinearLayoutManager(this@Cart)
        setUpToolbar()

        restaurant = sharedPreferencesRestaurant.getString("name", null)
        findViewById<TextView>(R.id.restaurant).text = restaurant

        itemList = itemCart(this@Cart).execute().get()

        //for making JSON Object

        var array = JSONArray()

        //Calculating Cost
        var totalCost: Int = 0
        for (i in 0 until itemList.size) {

            val JsonOb = JSONObject()
            JsonOb.put("food_item_id",itemList[i].id)
            array.put(JsonOb)

            //Total Sum
            totalCost += itemList[i].cost.toInt()
        }
        println(array)




        orderButton.text = "Place Order(Total Rs.$totalCost)"

        cartAdapter = cartAdapter(this@Cart, itemList)

        cartRecyclerView.adapter = cartAdapter

        cartRecyclerView.layoutManager = cartLayout






        orderButton.setOnClickListener {
            val userId = sharedPreferencesUser.getString("user_id", null)
            val resId = sharedPreferencesRestaurant.getString("id", null)




            val queue = Volley.newRequestQueue(this@Cart)

            val url = "http://13.235.250.119/v2/place_order/fetch_result/"

            val params = JSONObject()
            params.put("user_id", userId)
            params.put("restaurant_id", resId)
            params.put("total_cost", totalCost)
            params.put("food",array)



            if (ConnectionManager().checkConnectivity(this@Cart) == true) {

                val request =
                    object : JsonObjectRequest(Request.Method.POST, url, params, Response.Listener {

                        try{
                            val data = it.getJSONObject("data")

                            val success = data.getBoolean("success")

                            if(success){
                                val intent = Intent(this@Cart,Success::class.java)
                                startActivity(intent)
                            }
                            else{
                                Toast.makeText(this@Cart,"Some Error Occurred",Toast.LENGTH_SHORT).show()
                            }
                        }

                        catch (e:JSONException){
                            Toast.makeText(this@Cart,"Exception Error Occurred",Toast.LENGTH_SHORT).show()
                        }

                    },
                        Response.ErrorListener {
                            Toast.makeText(this@Cart,"Volley Error Occurred",Toast.LENGTH_SHORT).show()

                        }) {
                        override fun getHeaders(): MutableMap<String, String> {
                            val headers = HashMap<String, String>()
                            headers["Context-type"] = "application/json"
                            headers["token"] = "a64e7228772c2c"
                            return headers

                        }
                    }
                queue.add(request)
            }
            else{
                NoInternet(this@Cart)
            }


        }

    }

    class itemCart(val context: Context) : AsyncTask<Void, Void, List<ItemEntity>>() {
        val db = Room.databaseBuilder(context, ItemDatabase::class.java, "item-db").build()
        override fun doInBackground(vararg p0: Void?): List<ItemEntity> {
            return db.itemDao().getAllItems()
        }


    }

    fun setUpToolbar() {
        setSupportActionBar(CartToolbar)
        supportActionBar?.title = "Cart"
        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId

        if (id == android.R.id.home) {
            onBackPressed()
            return true
        } else {
            return onOptionsItemSelected(item)
        }
    }
}