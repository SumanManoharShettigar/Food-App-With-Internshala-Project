
package com.internshala.app.activity

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.AsyncTask
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.animation.AnimationUtils
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.cardview.widget.CardView
import androidx.room.Room
import com.internshala.app.R
import com.internshala.app.database.ItemDatabase

class Success : AppCompatActivity() {

    lateinit var successLogoLayout : CardView
    lateinit var Success :TextView
    lateinit var continueButton : Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_success)

        val animation = AnimationUtils.loadAnimation(this,R.anim.zoomin)

        successLogoLayout = findViewById(R.id.successLogoLayout)
        Success = findViewById(R.id.Success)

        successLogoLayout.startAnimation(animation)
        Success.startAnimation(animation)
        continueButton = findViewById(R.id.continueButton)
        continueButton.setOnClickListener {
            val id = clearDatabase(this@Success).execute()

            if(id.get()){
                val intent = Intent(this@Success,HomePage::class.java)
                startActivity(intent)
                finish()
            }
            else{
                Toast.makeText(this@Success,"Some Error Occurred",Toast.LENGTH_SHORT).show()
            }


        }





    }

    class clearDatabase(val context: Context):AsyncTask<Void,Void,Boolean>(){
        val db = Room.databaseBuilder(context,ItemDatabase::class.java,"item-db").build()
        override fun doInBackground(vararg p0: Void?): Boolean {
            db.itemDao().deleteAll()
            db.close()
            return true
        }

    }

    override fun onBackPressed() {

        val intent = Intent (this@Success,HomePage::class.java)
        startActivity(intent)

        finish()
        super.onBackPressed()
    }
}