package com.internshala.app.fragment

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.internshala.app.R

 class ProfileFragment : Fragment() {
    lateinit var sharedPreferences: SharedPreferences
     var Name : String? =null
     var Phone : String? = null
     var email : String? = null
     var address : String? = null



     override fun onCreateView(
         inflater: LayoutInflater, container: ViewGroup?,
         savedInstanceState: Bundle?
     ): View? {
         // Inflate the layout for this fragment
         val view = inflater.inflate(R.layout.fragment_profile, container, false)



         sharedPreferences =
             this.activity?.getSharedPreferences("User Details", Context.MODE_PRIVATE)!!

          Name = sharedPreferences.getString("Name",null)
         Phone = sharedPreferences.getString("MobileNumber",null)
         email = sharedPreferences.getString("Email",null)
         address = sharedPreferences.getString("address",null)

         view.findViewById<TextView>(R.id.Profilename).text = Name
         view.findViewById<TextView>(R.id.ProfilePhone).text = Phone
         view.findViewById<TextView>(R.id.ProfileEmail).text = email
         view.findViewById<TextView>(R.id.ProfileAddress).text = address



         return view
     }

 }