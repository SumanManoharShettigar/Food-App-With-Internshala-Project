package com.internshala.app.activity

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.ConnectivityManager
import android.opengl.Visibility
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.internshala.app.NoInternet
import com.internshala.app.R
import com.internshala.app.util.ConnectionManager
import kotlinx.android.synthetic.main.register.*
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.lang.reflect.Method

class Register : AppCompatActivity() {
    lateinit var txtRegName : EditText
    lateinit var txtRegEmail : EditText
    lateinit var txtRegPh : EditText
    lateinit var txtRegPwd : EditText
    lateinit var txtRegCnPwd : EditText
    lateinit var txtAddress : EditText
    lateinit var sharedPreferences: SharedPreferences
    lateinit var regProgressLayout : RelativeLayout
    lateinit var regProgressBar : ProgressBar
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.register)
        sharedPreferences =
            getSharedPreferences(getString(R.string.preference_file_name), Context.MODE_PRIVATE)

        txtRegName = findViewById(R.id.txtRegName)
        txtRegEmail = findViewById(R.id.txtRegEmail)
        txtRegPh = findViewById(R.id.txtRegPh)
        txtRegPwd = findViewById(R.id.txtRegPwd)
        txtRegCnPwd = findViewById(R.id.txtRegCnPwd)
        txtAddress = findViewById(R.id.txtAddress)

        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)





        btnRegister.setOnClickListener {


            val name = txtRegName.text.toString()
            val email = txtRegEmail.text.toString()
            val ph = txtRegPh.text.toString()
            val password = txtRegPwd.text.toString()
            val CnPassword = txtRegCnPwd.text.toString()
            val address = txtAddress.text.toString()



            if (name == "" || email == "" || ph == "" || password == "" || CnPassword == "") {
                Toast.makeText(this@Register, "Missing Credentials", Toast.LENGTH_LONG).show()
            } else if (CnPassword != password) {
                Toast.makeText(this@Register, "Password Not Matching", Toast.LENGTH_LONG).show()

            } else {

                val queue = Volley.newRequestQueue(this@Register)

                val url = "http://13.235.250.119/v2/register/fetch_result"

                val param = JSONObject()
                param.put("name", name)
                param.put("mobile_number", ph)
                param.put("password", password)
                param.put("address", address)
                param.put("email", email)

                if (ConnectionManager().checkConnectivity(this@Register) == true) {

                    val res = object : JsonObjectRequest(
                        Request.Method.POST, url, param, Response.Listener {

                            try {
                                println("hi")

                                val data1 = it.getJSONObject("data")

                                val success = data1.getBoolean("success")

                                println("response is $it")

                                if (success) {


                                    val data = data1.getJSONObject("data")

                                    val userId1 = data.getString("user_id").toString()
                                    val name1 = data.getString("name").toString()
                                    val email1 = data.getString("email").toString()
                                    val mobileNumber1 = data.getString("mobile_number").toString()
                                    val address1 = data.getString("address").toString()

                                    savePreference(
                                        userId1,
                                        name1,
                                        email1,
                                        mobileNumber1,
                                        password,
                                        address1
                                    )


                                    val intent = Intent(this@Register, HomePage::class.java)
                                    startActivity(intent)
                                    finish()

                                } else {

                                    val errorMessage = data1.getString("errorMessage")
                                    Toast.makeText(
                                        this@Register,
                                        errorMessage,
                                        Toast.LENGTH_SHORT
                                    ).show()

                                }


                            } catch (e: JSONException) {

                                Toast.makeText(this@Register, "Exception Error", Toast.LENGTH_SHORT)
                                    .show()

                            }

                        },

                        Response.ErrorListener {
                            Toast.makeText(this@Register, "Volley Error", Toast.LENGTH_SHORT).show()


                        }) {
                        override fun getHeaders(): MutableMap<String, String> {
                            val headers = HashMap<String, String>()
                            headers["Content-type"] = "application/json"
                            headers["token"] = "a64e7228772c2c"
                            return headers
                        }
                    }

                    queue.add(res)


                } else {
                    NoInternet(this@Register)
                }
            }
        }


        }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        if(id == android.R.id.home){
            onBackPressed()
            return true
        }
        return false
    }

    override fun onBackPressed() {
        finish()
        super.onBackPressed()
    }


        fun savePreference(
            userId: String,
            name: String,
            email: String,
            phone: String,
            password: String,
            address: String
        ) {
            sharedPreferences.edit().putString("Name", name).apply()
            sharedPreferences.edit().putString("Email", email).apply()
            sharedPreferences.edit().putString("MobileNumber", phone).apply()
            sharedPreferences.edit().putString("Password", password).apply()
            sharedPreferences.edit().putBoolean("isLoggedIn", true).apply()
            sharedPreferences.edit().putString("user_id", userId).apply()
            sharedPreferences.edit().putString("address", address).apply()



    }


}