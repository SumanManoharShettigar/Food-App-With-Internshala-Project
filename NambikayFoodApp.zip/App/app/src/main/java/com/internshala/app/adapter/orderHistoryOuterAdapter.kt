package com.internshala.app.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.internshala.app.Model.ItemList
import com.internshala.app.Model.OrderInfo
import com.internshala.app.R

class orderHistoryOuterAdapter(val context: Context, val orderInfo: List<OrderInfo>) :
    RecyclerView.Adapter<orderHistoryOuterAdapter.orderHistoryViewHolder>() {


    class orderHistoryViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val restaurantName: TextView = view.findViewById(R.id.restaurantName)
        val totalCost: TextView = view.findViewById(R.id.totalCost)
        val timeOfOrder: TextView = view.findViewById(R.id.timeOfOrder)
        val orderHistoryInnerRecyclerView: RecyclerView =
            view.findViewById(R.id.orderHistoryInnerRecyclerView)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): orderHistoryViewHolder {
        val view =
            LayoutInflater.from(context).inflate(R.layout.single_order_history_row, parent, false)
        return orderHistoryViewHolder(view)

    }

    override fun getItemCount(): Int {
        return orderInfo.size
    }

    override fun onBindViewHolder(holder: orderHistoryViewHolder, position: Int) {

        val info = orderInfo[position]

        holder.restaurantName.text = info.restaurantName
        holder.timeOfOrder.text = info.orderTime
        holder.totalCost.text = info.totalCost
        //To store the array of food items
        val foodItemsList: ArrayList<ItemList> = arrayListOf()

        val itemData = info.food_items

        for (i in 0 until itemData.length()) {

            val orderItemJsonObject = itemData.getJSONObject(i)

            val orderItemObject = ItemList(
                orderItemJsonObject.getString("food_item_id"),
                orderItemJsonObject.getString("name"),
                orderItemJsonObject.getString("cost")


            )

            foodItemsList.add(orderItemObject)
            val orderHistoryInnerLayout: RecyclerView.LayoutManager =
                LinearLayoutManager(context)

            val orderHistoryInnerAdapter: OrderHistoryInnerAdapter =
                OrderHistoryInnerAdapter(context, foodItemsList)

            holder.orderHistoryInnerRecyclerView.adapter = orderHistoryInnerAdapter
            holder.orderHistoryInnerRecyclerView.layoutManager = orderHistoryInnerLayout
        }


    }
}