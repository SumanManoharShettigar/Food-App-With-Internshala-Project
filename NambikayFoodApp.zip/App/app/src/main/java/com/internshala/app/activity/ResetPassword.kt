package com.internshala.app.activity

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.internshala.app.NoInternet
import com.internshala.app.R
import com.internshala.app.util.ConnectionManager
import kotlinx.android.synthetic.main.activity_reset_password.*
import org.json.JSONException
import org.json.JSONObject

class ResetPassword : AppCompatActivity() {

    lateinit var OTP : EditText
    lateinit var newPassword : EditText
    lateinit var cnPassword : EditText
    lateinit var sharedPreferences: SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reset_password)

        sharedPreferences = getSharedPreferences("User Details",Context.MODE_PRIVATE)

        OTP = findViewById(R.id.txtOTP)
        newPassword = findViewById(R.id.txtNewPassword)
        cnPassword = findViewById(R.id.txtConfirmNewPassword)

        val mobileNumber = sharedPreferences.getString("MobileNumber",null)



        btnApply.setOnClickListener {

            val otp = OTP.text.toString()
            val newPassword = newPassword.text.toString()
            val cnPassword = cnPassword.text.toString()

            val queue = Volley.newRequestQueue(this@ResetPassword)
            val url = "http://13.235.250.119/v2/reset_password/fetch_result"

            val params = JSONObject()
            params.put("mobile_number",mobileNumber)
            params.put("password",newPassword)
            params.put("otp",otp)
            println(mobileNumber)

            if(newPassword != cnPassword){
                Toast.makeText(this@ResetPassword,"Passwords Don't Match",Toast.LENGTH_SHORT)
            }



            else if(ConnectionManager().checkConnectivity(this@ResetPassword) == true){



                val request = object:JsonObjectRequest(Request.Method.POST,url,params,Response.Listener {
                    try {

                        val data = it.getJSONObject("data")

                        val success = data.getBoolean("success")
                        println(it)
                        if (success) {



                            val successMessage = data.getString("successMessage")

                            val successDialog = AlertDialog.Builder(this@ResetPassword,R.style.CustomDialogTheme)
                            successDialog.setTitle("Success!")
                            successDialog.setMessage(successMessage)
                            successDialog.setPositiveButton("Ok") { text, listener ->
                                val intent = Intent(this@ResetPassword, Login_Page::class.java)
                                startActivity(intent)
                                sharedPreferences.edit().clear().apply()
                                finish()
                            }

                            successDialog.create()
                            successDialog.show()
                        } else {
                            Toast.makeText(
                                this@ResetPassword,
                                "Some Error Occurred",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                    catch (e:JSONException){
                        Toast.makeText(
                            this@ResetPassword,
                            "Exception Error Occurred",
                            Toast.LENGTH_SHORT
                        ).show()


                    }



                },
                Response.ErrorListener {Toast.makeText(
                    this@ResetPassword,
                    "Volley Error Occurred",
                    Toast.LENGTH_SHORT
                ).show()

                }){
                    override fun getHeaders(): MutableMap<String, String> {
                        val headers = HashMap<String,String>()
                        headers["Content-type"]="application-json"
                        headers["token"] = "a64e7228772c2c"
                        return headers
                    }




                }
                queue.add(request)


            }
            else{
                NoInternet(this@ResetPassword)
            }



        }


    }
}