package com.internshala.app.fragment

import android.content.Context
import android.os.AsyncTask
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.internshala.app.R
import com.internshala.app.adapter.FavoriteAdapter
import com.internshala.app.database.RestaurantDataBase
import com.internshala.app.database.RestaurantEntity


class FavoriteRestaurantFragment : Fragment() {

    lateinit var favoriteRecycler: RecyclerView
    lateinit var progressLayout: RelativeLayout
    lateinit var progressBar: ProgressBar
    lateinit var layoutManager: RecyclerView.LayoutManager
    lateinit var favoriteAdapter: FavoriteAdapter
    lateinit var emptyFav: RelativeLayout
    lateinit var emptyFavLogo: ImageView
    lateinit var emptyFavText: TextView

    //To store Restaurant List
    var restaurantList = listOf<RestaurantEntity>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_favorite_restaurant, container, false)

        favoriteRecycler = view.findViewById(R.id.favoriteRecycler)
        progressBar = view.findViewById(R.id.progressBar)
        progressLayout = view.findViewById(R.id.progressBarLayout)
        progressBar.visibility = View.VISIBLE
        progressLayout.visibility = View.VISIBLE

        emptyFav = view.findViewById(R.id.emptyFav)
        emptyFavLogo = view.findViewById(R.id.emptyFavLogo)
        emptyFavText = view.findViewById(R.id.emptyFavText)
        emptyFav.visibility = View.GONE
        emptyFavLogo.visibility = View.GONE
        emptyFavText.visibility = View.GONE


        layoutManager = LinearLayoutManager(activity as Context)

        restaurantList = RetrieveFavorites(activity as Context).execute().get()

        if (activity != null) {
            progressLayout.visibility = View.GONE
            progressBar.visibility = View.GONE
            if (favoriteEmpty(activity as Context).execute().get()) {
                emptyFav.visibility = View.VISIBLE
                emptyFavLogo.visibility = View.VISIBLE
                emptyFavText.visibility = View.VISIBLE
            }
            favoriteAdapter = FavoriteAdapter(activity as Context, restaurantList)
            favoriteRecycler.adapter = favoriteAdapter
            favoriteRecycler.layoutManager = layoutManager

        }
        return view
    }

    class RetrieveFavorites(val context: Context) :
        AsyncTask<Void, Void, List<RestaurantEntity>>() {

        val db =
            Room.databaseBuilder(context, RestaurantDataBase::class.java, "restaurant-db").build()

        override fun doInBackground(vararg p0: Void?): List<RestaurantEntity> {

            return db.restaurantDao().getAllRestaurants()
            db.close()
        }

    }

    class favoriteEmpty(val context: Context) : AsyncTask<Void, Void, Boolean>() {

        val db =
            Room.databaseBuilder(context, RestaurantDataBase::class.java, "restaurant-db").build()

        override fun doInBackground(vararg p0: Void?): Boolean {

            if (db.restaurantDao().getCount() > 0) {
                return false
            } else {
                return true
            }
        }
    }

}

