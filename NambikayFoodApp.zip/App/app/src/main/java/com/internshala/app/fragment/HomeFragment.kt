package com.internshala.app.fragment

import android.app.Activity
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.SharedPreferences
import android.net.ConnectivityManager
import android.os.AsyncTask
import android.os.Bundle
import android.provider.Settings
import android.view.*
import androidx.fragment.app.Fragment
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.internshala.app.Model.Restaurant
import com.internshala.app.R
import com.internshala.app.adapter.HomeRecyclerAdapter
import com.internshala.app.adapter.RestaurantMenuAdapter
import com.internshala.app.database.RestaurantDataBase
import com.internshala.app.database.RestaurantEntity
import com.internshala.app.util.ConnectionManager
import com.squareup.picasso.Picasso
import org.json.JSONException
import java.util.*
import kotlin.Comparator
import kotlin.collections.HashMap


class HomeFragment : Fragment() {


    lateinit var recyclerView: RecyclerView
    lateinit var layoutManager: RecyclerView.LayoutManager
    lateinit var recyclerAdapter: HomeRecyclerAdapter
    lateinit var progressBar: ProgressBar
    lateinit var progressbarLayout: RelativeLayout


    var selectedItem = -1

    //Store the Array obtained from Json Object
    val restaurantInfoList = arrayListOf<Restaurant>()

    var sortOption = arrayOf("Name", "Cost(Low to High)", "Cost(High to Low)", "Rating")

    //For Sort Comparator
    val ratingComparator = Comparator<Restaurant> { restaurant1, restaurant2 ->

        if (restaurant1.res_Rating.compareTo(restaurant2.res_Rating, true) == 0) {
            restaurant1.res_Name.compareTo(restaurant2.res_Name, true)
        } else {
            restaurant1.res_Rating.compareTo(restaurant2.res_Rating, true)
        }
    }

    val nameComparator = Comparator<Restaurant> { restaurant1, restaurant2 ->

        if (restaurant1.res_Name.compareTo(restaurant2.res_Name, true) == 0) {
            restaurant1.res_Rating.compareTo(restaurant2.res_Rating, true)
        } else {
            restaurant1.res_Name.compareTo(restaurant2.res_Name, true)
        }
    }
    val costLHComparator = Comparator<Restaurant> { restaurant1, restaurant2 ->

        if (restaurant1.res_Cost.compareTo(restaurant2.res_Cost, true) == 0) {
            restaurant1.res_Rating.compareTo(restaurant2.res_Rating, true)
        } else {
            restaurant1.res_Cost.compareTo(restaurant2.res_Cost, true)
        }
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_home, container, false)
        //Initialise Recycler View
        recyclerView = view.findViewById(R.id.homeRecyclerView)

        //Initialise Layout Manager
        layoutManager = LinearLayoutManager(activity)

        //Initialise the ProgressBar and It's Layout
        progressBar = view.findViewById(R.id.progressBar)
        progressbarLayout = view.findViewById(R.id.progressBarLayout)

        //Show the progress bar when the fragment opens

        progressbarLayout.visibility = View.VISIBLE
        progressBar.visibility = View.VISIBLE

        //For Sort Icon

        setHasOptionsMenu(true)



        //Initialise queue to store the queue of request
        val queue = Volley.newRequestQueue(activity as Context)

        //Initialise the url
        val url = "http://13.235.250.119/v2/restaurants/fetch_result/"

        //Sending Request Only If Internet Is Available

        if (ConnectionManager().checkConnectivity(activity as Context)) {


            val jsonObjectRequest =
                object : JsonObjectRequest(Request.Method.GET, url, null, Response.Listener {
                    // try is used to counter the Json Error
                    try {

                        //Remove the Progress Bar
                        progressBar.visibility = View.GONE
                        progressbarLayout.visibility = View.GONE


                        // Listening To Response From the URL
                        val data1 = it.getJSONObject("data")

                        //Checking success status
                        val success = data1.getBoolean("success")
                        if (success) {
                            //Extracting data from JsonArray data
                            val data = data1.getJSONArray("data")
                            for (i in 0 until data.length()) {
                                //variable to store each object
                                val restaurantJsonObject = data.getJSONObject(i)

                                //Pass JSON object value to Restaurant Object
                                val restaurantObject = Restaurant(
                                    restaurantJsonObject.getString("id"),
                                    restaurantJsonObject.getString("name"),
                                    restaurantJsonObject.getString("rating"),
                                    restaurantJsonObject.getString("cost_for_one"),
                                    restaurantJsonObject.getString("image_url")

                                )

                                //Adding Restaurant Object to the Array List
                                restaurantInfoList.add(restaurantObject)

                                //Initialise the Recycler Adapter

                                recyclerAdapter =
                                    HomeRecyclerAdapter(activity as Context, restaurantInfoList)

                                recyclerView.adapter = recyclerAdapter

                                recyclerView.layoutManager = layoutManager

                            }
                        } else {
                            //Didnt recieve true for "success"

                            Toast.makeText(
                                activity as Context,
                                "Some Error Occurred!!",
                                Toast.LENGTH_SHORT
                            ).show()

                        }
                    } catch (e: JSONException) {
                        Toast.makeText(
                            activity as Context,
                            "Some Error Occurred",
                            Toast.LENGTH_SHORT
                        ).show()
                    }


                },
                    Response.ErrorListener {
                        //Responding to the Error
                        if (activity != null) {
                            Toast.makeText(
                                activity as Context,
                                "Volley Error Occurred",
                                Toast.LENGTH_SHORT
                            ).show()

                        }

                    }) {
                    //Sending Headers to the API which informs it about the context-type and token of the request
                    override fun getHeaders(): MutableMap<String, String> {
                        val headers = HashMap<String, String>()
                        headers["Content-type"] = "application/json"
                        headers["token"] = "a64e7228772c2c"
                        return headers
                    }

                }


            queue.add(jsonObjectRequest)
        } else {
            val dialog = AlertDialog.Builder(activity as Context,R.style.CustomDialogTheme)
            dialog.setMessage("No Internet Connection. Connect to Internet and reopen the app.")
            dialog.setTitle("Connection Error.")
            dialog.setPositiveButton("Settings") { text, listener ->
                val intent = Intent(Settings.ACTION_WIRELESS_SETTINGS)
                startActivity(intent)
                ActivityCompat.finishAffinity(activity!!)
            }



            dialog.setNegativeButton("Cancel") { text, listener ->
                ActivityCompat.finishAffinity(activity!!)

            }
            dialog.create()
            dialog.show()
        }



        return view


    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        //For Sort Symbol
        inflater?.inflate(R.menu.menu_home, menu)


    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item?.itemId
        if (id == R.id.sort) {


            val dialog = AlertDialog.Builder(activity as Context,R.style.CustomDialogTheme)
            dialog.setTitle("Sort by?")

            dialog.setSingleChoiceItems(sortOption, selectedItem) { text, i ->
                selectedItem = i


            }



            dialog.setPositiveButton("Close"){
                text, listener ->
                when(selectedItem){

                    0 -> {Collections.sort(restaurantInfoList,nameComparator)
                        //DO TELL THE ADAPTER ABOUT THE CHANGES
                        recyclerAdapter.notifyDataSetChanged()



                    }

                    1 -> {
                        Collections.sort(restaurantInfoList,costLHComparator)
                        //DO TELL THE ADAPTER ABOUT THE CHANGES
                        recyclerAdapter.notifyDataSetChanged()
                    }

                    2 ->{
                        Collections.sort(restaurantInfoList,costLHComparator)
                        restaurantInfoList.reverse()
                        //DO TELL THE ADAPTER ABOUT THE CHANGES
                        recyclerAdapter.notifyDataSetChanged()
                    }

                    3 -> {
                        Collections.sort(restaurantInfoList, ratingComparator)
                        restaurantInfoList.reverse()
                        //DO TELL THE ADAPTER ABOUT THE CHANGES
                        recyclerAdapter.notifyDataSetChanged()
                    }

                }
            }


            dialog.create()
            dialog.show()






            return super.onOptionsItemSelected(item)

        }
        return super.onOptionsItemSelected(item)


    }
}
