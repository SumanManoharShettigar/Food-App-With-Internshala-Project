package com.internshala.app.database

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query

@Dao
interface RestaurantDao {

    //Every function here only has declaration and not function body because ROOM Library does that job for US!!!!!. So it is an INTERFACE and not CLASS

    @Insert
    fun insertRestaurant(restaurantEntity: RestaurantEntity)

    @Delete
    fun deleteRestaurant(restaurantEntity: RestaurantEntity)

    //To display favourite restaurants in the favourite Fragment
    @Query("SELECT * FROM restaurants")
    fun getAllRestaurants() : List<RestaurantEntity>

    @Query("SELECT COUNT(res_id) FROM restaurants")
    fun getCount():Int

    //To check whether a Restaurant is a favorite one
    @Query("SELECT * FROM restaurants WHERE res_id = :restaurantId")
    //In restaurantId , " : " is added because it will get a value when called later
    fun getRestaurantById(restaurantId : String): RestaurantEntity


}