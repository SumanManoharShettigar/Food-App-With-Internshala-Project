package com.internshala.app.Model

data class Restaurant (
    val res_id : String,
    val res_Name : String,
    val res_Rating : String,
    val res_Cost : String,
    val res_Image : String
)