package com.internshala.app.splashScreen

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.view.animation.AnimationUtils
import com.internshala.app.R
import com.internshala.app.activity.HomePage
import com.internshala.app.activity.Login_Page
import kotlinx.android.synthetic.main.splash__screen.*

class Splash_Screen : AppCompatActivity() {

    private val SPLASH_TIME_OUT:Long = 1000
    lateinit var sharedPreferences: SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.splash__screen)
        sharedPreferences = getSharedPreferences(getString(R.string.preference_file_name), Context.MODE_PRIVATE)
        var isLoggedIn = sharedPreferences.getBoolean("isLoggedIn",false)

        imageView.visibility = View.VISIBLE
        textView.visibility = View.VISIBLE

        val animation = AnimationUtils.loadAnimation(this,
            R.anim.zoomin
        )
        imageView.startAnimation(animation)
        textView.startAnimation(animation)


        Handler().postDelayed({
            if (isLoggedIn){
            startActivity(Intent(this, HomePage::class.java))
                }
            else{
                startActivity(Intent(this,
                    Login_Page::class.java))
            }
            finish()
        },SPLASH_TIME_OUT)
    }
}