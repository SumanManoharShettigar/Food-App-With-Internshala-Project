package com.internshala.app.fragment


import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.internshala.app.Model.ItemList
import com.internshala.app.Model.OrderInfo
import com.internshala.app.NoInternet
import com.internshala.app.R
import com.internshala.app.adapter.OrderHistoryInnerAdapter
import com.internshala.app.adapter.orderHistoryOuterAdapter
import com.internshala.app.util.ConnectionManager
import org.json.JSONException

class OrderHistoryFragment : Fragment() {
    lateinit var orderHistoryOuterRecyclerView: RecyclerView
    lateinit var outerLayout: RecyclerView.LayoutManager
    lateinit var orderHistoryOuterAdapter: orderHistoryOuterAdapter
    lateinit var orderHistoryProgressBarLayout: RelativeLayout
    lateinit var orderHistoryProgressBar: ProgressBar
    lateinit var sharedPreferences: SharedPreferences
    lateinit var noOrder : RelativeLayout
    lateinit var noOrderLogo : ImageView
    lateinit var noOrderText : TextView

    var orderInfoList = arrayListOf<OrderInfo>()


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.order_history_fragment, container, false)
        sharedPreferences = context?.getSharedPreferences("User Details", Context.MODE_PRIVATE)!!
        orderHistoryOuterRecyclerView = view.findViewById(R.id.orderHistoryOuterRecyclerView)
        orderHistoryProgressBar = view.findViewById(R.id.orderHistoryProgressBar)
        orderHistoryProgressBarLayout = view.findViewById(R.id.orderHistoryProgressBarLayout)
        outerLayout = LinearLayoutManager(activity)

        orderHistoryProgressBar.visibility = View.VISIBLE
        orderHistoryProgressBarLayout.visibility = View.VISIBLE

        noOrder = view.findViewById(R.id.noOrder)
        noOrderLogo = view.findViewById(R.id.noOrderLogo)
        noOrderText = view.findViewById(R.id.noOrderText)

        noOrder.visibility = View.GONE
        noOrderLogo.visibility = View.GONE
        noOrderText.visibility = View.GONE

        val queue = Volley.newRequestQueue(activity as Context)
        val user_id = sharedPreferences.getString("user_id", null)
        val url = "http://13.235.250.119/v2/orders/fetch_result/$user_id"


        if (ConnectionManager().checkConnectivity(activity as Context)) {


            val request =
                object : JsonObjectRequest(Request.Method.GET, url, null, Response.Listener {
                    try {
                        orderHistoryProgressBar.visibility = View.GONE
                        orderHistoryProgressBarLayout.visibility = View.GONE

                        val data1 = it.getJSONObject("data")


                        val success = data1.getBoolean("success")



                        if (success) {

                            val data = data1.getJSONArray("data")

                            if(data.toString() == "[]" ){
                                noOrder.visibility = View.VISIBLE
                                noOrderLogo.visibility = View.VISIBLE
                                noOrderText.visibility = View.VISIBLE

                            }


                            for (i in 0 until data.length()) {
                                val orderInfoJsonObject = data.getJSONObject(i)


                                val orderInfoObject = OrderInfo(
                                    orderInfoJsonObject.getString("order_id"),
                                    orderInfoJsonObject.getString("restaurant_name"),
                                    orderInfoJsonObject.getString("total_cost"),
                                    orderInfoJsonObject.getString("order_placed_at"),
                                    orderInfoJsonObject.getJSONArray("food_items")
                                )



                                orderInfoList.add(orderInfoObject)

                                orderHistoryOuterAdapter =
                                    orderHistoryOuterAdapter(activity as Context, orderInfoList)

                                orderHistoryOuterRecyclerView.adapter = orderHistoryOuterAdapter

                                orderHistoryOuterRecyclerView.layoutManager = outerLayout


                            }


                        } else {
                            Toast.makeText(
                                activity as Context,
                                "Some error occurred.",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    } catch (e: JSONException) {

                        Toast.makeText(
                            activity as Context,
                            "Exception error occurred.",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
                    ,
                    Response.ErrorListener {
                        Toast.makeText(
                            activity as Context,
                            "Volley error occurrred",
                            Toast.LENGTH_SHORT
                        ).show()
                    }) {
                    override fun getHeaders(): MutableMap<String, String> {
                        val headers = HashMap<String, String>()
                        headers["Content-type"] = "application/json"
                        headers["token"] = "a64e7228772c2c"
                        return headers
                    }


                }
            queue.add(request)

        } else {
            NoInternet(activity as Context)


        }




        return view
    }


}

