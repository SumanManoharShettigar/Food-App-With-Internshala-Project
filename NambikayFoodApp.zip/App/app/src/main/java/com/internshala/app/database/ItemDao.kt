package com.internshala.app.database

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query

@Dao
interface ItemDao {
    @Insert
    fun insertItem(itemEntity: ItemEntity)

    @Delete
    fun deleteItem(itemEntity: ItemEntity)

    @Query("DELETE FROM item")
    fun deleteAll()

    @Query("SELECT COUNT(id) FROM item")
    fun getCount() : Int

    @Query("SELECT * FROM item")
    fun getAllItems() : List<ItemEntity>

    //For checking whether added to Cart
    @Query("SELECT * FROM item WHERE id = :itemId ")
    fun getItemId(itemId : String) : ItemEntity

}