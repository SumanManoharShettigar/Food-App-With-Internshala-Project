package com.internshala.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.internshala.app.fragment.HomeFragment

fun NoInternet(context: Context) : Unit {

    val dialog = AlertDialog.Builder(context,R.style.CustomDialogTheme)
    dialog.setTitle("Internet Error.")
    dialog.setMessage("No Internet Connection. Connect to the Internet.")
    dialog.setNegativeButton("Cancel"){
        text, listener ->





    }
    dialog.setPositiveButton("Settings"){
        text,listener -> val intent = Intent(Settings.ACTION_WIRELESS_SETTINGS)
        context.startActivity(intent)


    }

    dialog.create()
    dialog.show()



}